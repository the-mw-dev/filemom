import Fastify from 'fastify';
import { randomInt } from 'crypto';
import pointOfView from '@fastify/view';
import ejs from 'ejs';

const crypto = require('crypto');
const fastify = Fastify();
const servers = Object.freeze({ 'tp.rabstvo.pro': 'http://195.62.49.224:3009' });

fastify.register(pointOfView, {
  engine: {
    ejs
  }
});

const variants = {
  'A': ['\u200B\u200B𝐀\u200B\u200B\u200B', '\u200B\u200B\u200B𝔸\u200C\u200C', '\u200C\u200CΛ', 'Ⱥ', 'Á\u200B'],
  'B': ['\u200B\u200B𝐁', '\u00A0\u00A0𝔹\u200C\u200C', '\u200B\u200Bß', '\u00A0\u00A0\u00A0Ɓ\u00A0\u00A0', '\u200B\u200BB̀\u00A0\u00A0'],
  'C': ['\u00A0\u00A0\u00A0𝐂', 'ℂ\u200B\u200B', '\u200C\u200CƆ\u200C\u200C\u200C', '\u200B₵\u200B', '\u200B\u200BÇ'],
  'D': ['𝐃\u200B\u200B', '𝔻\u200B', 'Ɖ', 'Ď\u00A0', '\u200BĐ\u200B'],
  'E': ['𝐄\u00A0', '\u200C𝔼\u00A0\u00A0', 'Ɛ\u200B\u200B', '\u200C\u200C\u200CЕ\u200B', '\u00A0\u00A0\u00A0È\u200B\u200B\u200B'],
  'F': ['\u200B\u200B\u200B𝐅', '𝔽\u00A0\u00A0', '\u00A0\u00A0\u00A0Ƒ\u00A0\u00A0\u00A0', '\u200B\u200B\u200B𝒻\u200B', '\u200C\u200C\u200CF́\u200B\u200B'],
  'G': ['\u200B𝐆\u200B\u200B', '\u200B\u200B\u200B𝔾\u00A0\u00A0', '\u200B\u200B\u200BƓ', '\u00A0𝒢\u200C\u200C\u200C', '\u200B\u200B\u200BĜ'],
  'H': ['𝐇\u00A0', 'ℋ\u00A0', '\u00A0\u00A0\u00A0Н\u200C\u200C\u200C', '\u200C\u200C\u200CН̃\u200B\u200B\u200B', '\u200BĤ\u200B'],
  'I': ['\u200B\u200B\u200B𝐈\u200B', '\u200C𝘐\u00A0\u00A0\u00A0', 'Ι\u200C\u200C', '\u200Bİ\u200B\u200B\u200B', 'Î\u200C\u200C'],
  'J': ['𝐉\u200B\u200B\u200B', '𝒥', '\u00A0\u00A0Ј\u00A0\u00A0', 'Ĵ\u00A0\u00A0\u00A0', 'Ј̌\u200B\u200B\u200B'],
  'K': ['\u200B\u200B\u200B𝐊', '\u200C𝒦\u200B\u200B', '\u200B\u200B\u200BΚ', '\u00A0\u00A0Ķ\u00A0', '\u200BK̂\u200B\u200B\u200B'],
  'L': ['𝐋', '\u200B\u200B\u200B𝑳\u00A0\u00A0\u00A0', '\u200B\u200Bℒ\u200C\u200C\u200C', '\u00A0\u00A0Ł\u200C\u200C', '\u200BĹ\u200B\u200B'],
  'M': ['\u200B𝐌', '\u00A0\u00A0𝑴\u200C\u200C\u200C', '\u00A0\u00A0\u00A0М\u200B\u200B\u200B', 'M̃', 'М́'],
  'N': ['\u00A0\u00A0𝐍\u200B\u200B', '\u00A0𝑵', '\u200C𝒩', 'Ń', '\u200B\u200BŇ\u200C'],
  'O': ['𝐎\u00A0', '\u200B\u200B\u200B𝒪', 'О', '\u200B\u200BŌ', '\u00A0\u00A0Ó'],
  'P': ['\u200B\u200B\u200B𝐏\u200B', '\u200C𝒫\u00A0\u00A0\u00A0', '\u00A0\u00A0\u00A0Р\u200C\u200C', '\u200B\u200B\u200BƤ\u200B\u200B', '\u200BP̀\u200B'],
  'Q': ['𝐐\u200B', '\u200B\u200B𝒬\u200B\u200B\u200B', '𝑄\u00A0\u00A0\u00A0', '\u200CQ́\u00A0', 'Q̃\u200B'],
  'R': ['\u200C𝐑', 'ℝ\u00A0\u00A0', '\u00A0\u00A0Я\u200B\u200B', '\u200CŘ', 'Р̌\u00A0\u00A0'],
  'S': ['\u200B\u200B𝐒\u00A0\u00A0\u00A0', '𝒮\u200C', '\u200B\u200B\u200BЅ\u200C', '\u200B\u200B\u200BŜ\u200C\u200C', '\u00A0\u00A0Ş\u200C'],
  'T': ['\u200B𝐓\u200C', '𝒯', '\u200B\u200B\u200BТ\u200C\u200C\u200C', '\u200BŢ\u200B\u200B', '\u200C\u200C\u200CŤ\u200B\u200B'],
  'U': ['\u00A0\u00A0𝐔', '\u00A0\u00A0𝒰\u00A0\u00A0\u00A0', '\u200B\u200BŨ\u200B', '\u200BƯ', '\u200B\u200B\u200BÚ\u200B'],
  'V': ['𝐕', '\u200C\u200C\u200C𝒱\u200B\u200B', '\u00A0Ⅴ\u200C', 'ⱴ\u200B', '\u00A0V̌\u200B\u200B'],
  'W': ['\u200B𝐖', '𝒲\u200C\u200C\u200C', 'Щ\u00A0\u00A0', '\u200CŴ', '\u00A0\u00A0W̛'],
  'X': ['\u00A0\u00A0𝐗\u200B\u200B\u200B', '\u200C\u200C𝒳\u200B\u200B', 'Χ', 'Ӿ', '\u200C\u200CX̃'],
  'Y': ['\u200C\u200C𝐘\u200C\u200C', '𝒴\u200C\u200C', '\u200BҮ', '\u00A0\u00A0Ÿ\u200B\u200B', 'Ý'],
  'Z': ['\u200C\u200C𝐙\u00A0\u00A0', '\u200Bℤ\u200C\u200C', '\u200B\u200BΖ\u200B\u200B', '\u00A0\u00A0Ź\u200C\u200C', 'Ž\u200B\u200B']
};

function generateRandomLetters() {
  let sl = [];
  let l = Object.keys(variants);
  while (sl.length < 3) {
    let b = l[Math.floor(Math.random() * l.length)];
    if (!sl.includes(b)) {
      sl.push(b);
    }
  }
  let sequence = sl.map(bukva => variants[bukva][Math.floor(Math.random() * variants[bukva].length)]);
  return { sl, sequence };
}

async function encrypttextwithkey(text, key) {
  const encoder = new TextEncoder();
  const encodedText = encoder.encode(text);

  const cryptoKey = await crypto.subtle.importKey(
      'raw',
      encoder.encode(key),
      { name: 'AES-GCM' },
      false,
      ['encrypt']
  );

  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      cryptoKey,
      encodedText
  );

  const ivString = btoa(String.fromCharCode(...iv));
  const encryptedString = btoa(String.fromCharCode(...new Uint8Array(encrypted)));
  const cookieValue = `${ivString}:${encryptedString}`;
  return cookieValue;
}

async function decrypttextwithkey(text, key) {
 try {
  const parts = text.split(':');
  if (parts.length !== 2) {
    return '';
  }

  const [ivString, encryptedString] = parts;
  const iv = Uint8Array.from(atob(ivString), c => c.charCodeAt(0));
  const encryptedData = Uint8Array.from(atob(encryptedString), c => c.charCodeAt(0));

  const cryptoKey = await crypto.subtle.importKey(
      'raw',
      new TextEncoder().encode(key),
      { name: 'AES-GCM' },
      false,
      ['decrypt']
  );

  const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      cryptoKey,
      encryptedData
  );

  return new TextDecoder().decode(decrypted);
 } catch {
  return '';
 }
}

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

fastify.post('/mwprotect/captcha/generate', async (request, reply) => {
    const {sl, sequence} = generateRandomLetters();
    let points = [];
    for (let i of sequence) {
      points.push({ label: i, x: randomInt(50, 300), y: randomInt(50, 300) });
    }
    const ecmsg = await encrypttextwithkey(JSON.stringify({ points: sequence, timestamp: Date.now() }), 'bada15b054b07658e59125c3e85394d3');
    reply.header('Set-Cookie', `mwprotect_captcha=${ecmsg}; Path=/; HttpOnly`);
    return reply.send({ sl, points: shuffleArray(points) });
  });

fastify.post('/mwprotect/captcha/validate', async (request, reply) => {
  const { sequence } = request.body;
  const captchaData = await decrypttextwithkey(request.cookies?.mwprotect_captcha, 'bada15b054b07658e59125c3e85394d3');
  if (!captchaData) {
    return reply.status(400).send('Captcha not found');
  }

  const { points, timestamp } = JSON.parse(captchaData);
  const timeTaken = Date.now() - timestamp;

  if (timeTaken < 2000) {
    return reply.status(400).send('So Fast');
  }

  if (JSON.stringify(sequence) !== JSON.stringify(points)) {
    return reply.status(400).send('Error');
  }
  const now = Math.floor(Date.now() / 1000);
  const expiresIn6Hours = now + 6 * 60 * 60;
  const cookieValue = await encrypttextwithkey(`${request.headers['cf-connecting-ip'] || request.ip}#-${expiresIn6Hours}`, 'bada15b054b07658e59125c3e85394d3');
  reply.header('Set-Cookie', `mwprotect_id=${cookieValue}; Path=/; HttpOnly`);
  return reply.send('OK');
});

fastify.all('/*', async (request, reply) => {
    if (request.url.startsWith('/mwprotect/captcha')) {
        return reply;
      }
    const mwprotectId = request.cookies?.mwprotect_id;
    let ip = request.headers['cf-connecting-ip'] || request.ip;
    if (!mwprotectId) {
      return reply.status(403).view('/home/ubuntu/srvtp/captcha.ejs', {
        ip: request.headers['cf-connecting-ip'] || request.ip,
        worker: 'Netherlands-1'
      });
    }
    const decrypted = await decrypttextwithkey(mwprotectId, 'bada15b054b07658e59125c3e85394d3');
    if (ip !== decrypted.split('#-')[0] || decrypted.split('#-')[1] < Math.floor(Date.now() / 1000)) {
      return reply.status(403).view('/home/ubuntu/srvtp/captcha.ejs', {
        ip: request.headers['cf-connecting-ip'] || request.ip,
        worker: 'Netherlands-1'
      });
    }
    const targetUrl = servers[request.hostname] + request.url;
  
    try {
      const proxyRes = await fetch(targetUrl, {
        method: request.method,
        headers: request.headers,
        body: request.body,
        timeout: 10000
      });
  
      if (proxyRes.status === 502 || proxyRes.status === 504) {
        const errorText = proxyRes.status === 502 ? 'Bad Gateway' : 'Gateway Timeout';
        return reply.view('/home/ubuntu/srvtp/error.ejs', {
          ip: request.headers['cf-connecting-ip'] || request.ip,
          worker: 'Netherlands-1',
          error: proxyRes.status,
          errorText
        });
      }
  
      const body = await proxyRes.arrayBuffer();
      const headers = Object.fromEntries(proxyRes.headers.entries());
      reply.headers(headers);
      return reply.status(proxyRes.status).send(Buffer.from(body));
    } catch (err) {
      console.log(err);
      return reply.view('/home/ubuntu/srvtp/error.ejs', {
        ip: request.headers['cf-connecting-ip'] || request.ip,
        worker: 'Netherlands-1',
        error: '522',
        errorText: 'Connection Timed Out'
      });
    }
  });  

fastify.register(import('@fastify/cookie'));

fastify.listen({ port: 80, host: '0.0.0.0' }, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  console.log('Server running on http://0.0.0.0:80');
});
